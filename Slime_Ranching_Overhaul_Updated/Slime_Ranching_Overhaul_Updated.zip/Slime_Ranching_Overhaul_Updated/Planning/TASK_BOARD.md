# Rider GPT task board

Work one checked item at a time; compile and test in-game after each vertical slice. Never ask GPT to implement the entire mod in one prompt.

## Stage 1 — foundation
- [x] Create SMAPI mod skeleton and verify launch/logs.
- [ ] Design external-only hutch slime identity matching; prove wild and mine slimes are untouched. A read-only `slime_ranching_probe_identity` command is available to test `NPC.id` across save/reload; this candidate is not yet approved as stable.
- [x] Define versioned per-slime genome IDs and a registry under the installed mod folder. (Live slime identity mapping is still open.)
- [ ] Verify the Ranch Slime FarmAnimal is housed/pettable in the new Slime Daycare, then confirm its native ID remains stable and unique across save/reload before relying on it as the external genome key.
- [x] Implement idempotent first-install detection and first-seen snapshot of legacy hutch slimes in the mod folder.
- [x] Decide whether any opt-in legacy migration may change game entities: the explicit starter-reset command clears hutch slimes and grants one mod Common Slime Egg. The command still needs in-game verification.
- [ ] Add backup/reinstall reconciliation and recovery tests.

The first-seen load/save/hutch-inspection smoke check passed on the disposable `TaumTest_322865388` copy: seven vanilla hutch slimes stayed unmanaged and the external registry reloaded. This does not prove live slime identity or recovery after reinstall.

## Stage 2 — fully custom breeding
- [ ] Place and open breeder UI; select exactly two mature, eligible managed hutch slimes.
- [ ] Reserve/remove parents from free movement; show their actual size/color bouncing in transparent chamber.
- [ ] Implement cycle timing, parent cooldown, cancellation and crash/reload recovery.
- [ ] Prove an external-only egg identity mechanism before generating and storing a fixed genome in the mod registry.
- [ ] Prevent differing genomes stacking; test inventory, chests, drops, shipping, machine transfers.
- [ ] Intercept incubator hatch for managed eggs only; create correct juvenile with exact genome.
- [ ] Disable vanilla reproduction only for managed hutch slimes; verify all other slime behavior unchanged.

## Stage 3 — genetics
- [ ] Fixed color-wheel recipe table and tests; record unresolved Pink recipes explicitly.
- [ ] Separate size genetics from maturity; implement five sizes and visual scaling.
- [ ] Independent shiny/rarity/mutation flags; store ancestry and hybrid ability IDs.

## Stage 4 — furniture
- [ ] Marnie's shop inventory; trampoline animation and interaction framework.
- [ ] Use each slime's stored liked food when the Compost Trough is implemented; decide its bonus and consume only eligible items.
- [ ] Beds, slide, tunnel, ball pit, heated stone, pond, compost trough; persistence and QA.

## Stage 5 — machines
- [ ] Mutagenic Pool with per-slime pity and safe failure.
- [ ] Chromatic Crystals as breeder consumables, **not furniture**.
- [ ] Gel Refinery stored Slime and vanilla-item conversion recipes.

## Stage 6 — custom companion AI
- [ ] Slime Core bind/unbind, ownership, transfer and anti-duplication rules.
- [ ] Custom movement, pathfinding, transitions, stuck recovery, action scheduler.
- [ ] Inventory, ability targeting, cooldown and size/shiny scaling.

## Stage 7 — all types
- [ ] Seven base ability behaviors and six hybrids.
- [ ] Black extra night hour, White extra morning hour; test day-transition edge cases.
- [ ] Golden discount caps; Prismatic mount + Adaptation; Shadow Clone without recursive duplication.
- [ ] AI-generated art prepared as usable pixel sprites; visuals reviewed in-game.

## Stage 8 — release
- [ ] Reinstall/vanilla-load test matrix, compatibility and economy balance.
- [ ] Documentation and recovery instructions; single-player alpha packaging.

## Reusable Rider prompt
> Implement only the next unchecked task. Inspect existing code and Stardew/SMAPI API before choosing hooks. Do not affect non-managed slimes or write mod state into the game save. Keep external state versioned and recoverable. Include tests, a manual in-game verification checklist, and explain any uncertain API assumptions. Do not silently simplify the custom breeder or companion AI.
