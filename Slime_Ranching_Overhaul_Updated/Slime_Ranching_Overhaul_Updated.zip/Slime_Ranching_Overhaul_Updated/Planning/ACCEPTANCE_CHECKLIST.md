# Acceptance checklist by release gate

## Sprint 1: core alpha
- [ ] Mod starts without errors; external state and first-seen snapshot stay in the mod folder, with no automatic legacy cleanup.
- [ ] Wild and mine slimes untouched; hutch-only managed behavior.
- [ ] Breeder has two visible parents, fixed genome egg and hatchable juvenile.
- [ ] Fixed color recipes, five genetic sizes and shiny/rare data persist after save/load.

## Sprint 2: hutch alpha
- [ ] Marnie sells functional furniture; trampoline bounces slimes.
- [ ] Mutagenic Pool pity and Gel Refinery item conversion persist.

## Sprint 3: companion alpha
- [ ] Slime Core binds one existing slime, follows and uses base/hybrid abilities.
- [ ] Collector inventory survives warps and reloads.

## Sprint 4: extended alpha
- [ ] Shadow Clone and Golden/Prismatic abilities are capped and tested.
- [ ] Black/White time changes either pass day-transition tests or remain disabled.
- [ ] Uninstall/reinstall instructions and smoke-test results are documented.
