# Roadmap — fundamentals first, all slime types last

| Stage | Scope | Exit gate |
|---|---|---|
| 1 Foundation | SMAPI setup, external-only state, hutch-only ownership design, legacy snapshot | Mine/wild slimes unchanged; repeated loads safe; mod-folder backup recovery tested |
| 2 Fully custom breeding | Select exactly two mature parents; visible enclosure animations; cycle/cooldown; fixed-genome egg identity held externally; hatch juvenile | Breed → egg → hatch → reload succeeds without identity loss |
| 3 Genetics framework | Fixed color-wheel recipes, hybrid ability identifiers, five inherited sizes, rarity/shiny/mutation fields; use placeholder species | Deterministic test fixtures for inheritance and no rerolls |
| 4 Furniture | Marnie's catalogue, placeable trampoline, beds, slide, tunnel, playground, heated stone, pond, compost trough | Buy/place/use, interactions animate, persist on reload |
| 5 Advanced machines | Mutagenic Pool with per-slime pity; breeder Chromatic Crystal consumables; Gel Refinery | Recipes and machine state survive reload; no unintended stacking |
| 6 Custom companion AI | Slime Core binding; bespoke following/pathfinding/location transitions/target selection/action scheduling/inventory | Companion reliably follows, acts, and never duplicates |
| 7 Complete slime types | Seven base roles, six tertiary hybrids, Black/White, Golden, Prismatic, Shadow Clone; rare powers | Every planned type has visuals, rules, and tested ability |
| 8 Stabilization | Balance, AI-generated sprites, single-player compatibility, save lifecycle and release | Regression suite and rollback instructions pass |

**Release sequencing:** A playable breeding prototype after Stage 2; a genetics alpha after Stage 3; all planned types and their powers only after Stage 7. Do not treat later implementation as removal from core scope.

**Deliberate deferrals:** Multiplayer, cosmetic transmutation, advanced ancestry UI. **Not cut:** full custom breeding, custom companion AI, any agreed slime types, interactive furniture, refinery or mutation pool.
