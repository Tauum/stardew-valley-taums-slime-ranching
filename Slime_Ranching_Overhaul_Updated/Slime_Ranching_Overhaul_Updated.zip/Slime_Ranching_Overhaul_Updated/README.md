# Slime Ranching Overhaul — Current Development Plan

**Status:** Foundation implementation in progress; breeding is not yet implemented. **Stack:** Stardew Valley 1.6+, SMAPI, C#, Rider + GPT. **Release scope:** single-player first; multiplayer deferred.

The current code in the repository root stores the versioned genome registry and first-seen snapshot under `<installed mod folder>/data/saves/<save name>/`. A prototype Ranch Slime uses Stardew's `FarmAnimal` type and the game's built-in animal ID; the genome linked to that ID is stored in the mod folder. A new Slime Daycare building provides the animal-house interior for modded Ranch Slimes, leaving the vanilla Slime Hutch and vanilla GreenSlime monsters alone. The Daycare and animal prototype still need in-game verification and use Barn visuals as placeholders. The snapshot contains a JSON hutch inventory and read-only copies of the original save files when available. An opt-in `slime_ranching_initialize <exact save folder name>` command removes current Slime Hutch slimes and gives one mod Common Slime Egg. A separate Slime Egg Converter accepts any of the five vanilla Slime Eggs and produces one mod Common Slime Egg after ten in-game minutes. Vanilla eggs in inventories, chests, drops, treasure, and the old Slime Egg-Press are unchanged unless placed into the converter. The converter is available through the `slime_ranching_give_converter <exact save folder name>` test command. It uses the vanilla press sprite as a placeholder. The mod egg uses the vanilla green egg sprite as a placeholder and is not yet incubatable. There is no breeder yet.

## Rider build jobs

Run `1 Rebuild Slime Ranching`, then `2 Copy Slime Ranching to Mods` from Rider's run configurations, or run `3 Build, Deploy, Run` to do both and launch Stardew through SMAPI. The combined job stays open while the game runs and shows SMAPI output or launch errors in Rider. The copy step installs to `E:\Games\Steam\steamapps\common\Stardew Valley\Mods\taums-slime-ranching` and preserves the installed `config.json` and `data` directory. A normal project build still compiles without deploying.

## Read in order
1. `Planning/ROADMAP.md` — eight incremental stages and gates.
2. `Stages/01_Foundation.md` — hutch-only isolation, first-install snapshot and recovery.
3. `Stages/02_Custom_Breeding.md` — **first gameplay feature**: fully custom breeder, two animated parents, and fixed-genome eggs with an external identity design still to resolve.
4. `Planning/TASK_BOARD.md` — small, testable Rider GPT tasks.
5. `Technical/VANILLA_ISOLATION_AND_LIFECYCLE.md` — save-safety requirements.

## Player guide

See `Guides/PLAYER_GUIDE.md` for detailed instructions on the converter, inspection command, field guide book, optional starter reset, data locations, and which features are still unavailable. For testing, `slime_ranching_give_guidebook <exact save folder name>` adds the in-game field guide.

## Locked scope
- **Fully custom breeding**, not vanilla reproduction with a menu: two selected mature ranch slimes are visibly held in an animated enclosure, cycle finishes in a genetically fixed egg, then hatching creates a juvenile.
- Vanilla Slime Egg items/sprites are preferred. Distinct genomes must remain distinguishable through inventory, chests, machines and incubators without writing mod metadata into the game save. The required identity mechanism is unresolved.
- Colors, genetic sizes, rarity, and mutations are separate persistent data. All proposed slime types and hybrid abilities remain in scope, but species powers are implemented late.
- **Custom companion AI and movement**, including navigation, actions, storage and riding, are mandatory—not a vanilla follower reskin.
- Furniture is bought from Marnie and slimes physically use it (trampoline, beds, slides, etc.).
- AI-assisted/generated artwork is planned; placeholder art first. Generated images will require sprite-sheet preparation and in-game QA.
- Single-player v1; multiplayer explicitly deferred. Cosmetic item transmutation and elaborate family-tree UI may follow v1.

## Time planning
Custom breeding and custom companion AI remain expensive. Rough **20–40 h** for a save-safe breeding prototype and **110–190 h** for a feature-complete single-player alpha, with substantial uncertainty depending on SMAPI integration and artwork iteration. Not a promise.

## Important
Uninstalling cannot execute cleanup logic. All mod state is stored in the installed mod folder, so back up its `data` directory before removing or replacing the mod. Removing that directory loses the external registry. `config.json` contains preferences only.
