# Test strategy

## Current foundation smoke test

Use a copy of a single-player save with at least one existing Slime Hutch and one mine slime.

1. Load it with the mod and check the SMAPI log for a successful external registry load. In the hutch, `slime_ranching_inspect` should report the vanilla slime count and no managed slimes.
2. Check `<installed mod folder>/data/saves/<save name>/first-seen/`: `first-seen-v1.json`, the original save file, and `SaveGameInfo` (if present) should exist. Keep the first snapshot and compare its timestamp and content after another load; it must not be replaced. Nothing should be created in the game's save folder by this mod.
3. Save and reload. The mod folder should now contain `slime-registry-v1.json`; the hutch should still report no managed slimes. Mine slimes should behave as before.
4. Repeat with a new save and an empty hutch; the first-seen JSON may exist before the game's first on-disk save.
5. Test a damaged first-seen file on a disposable mod-data copy. If the snapshot cannot be verified, the mod should log an error and leave its registry disabled for that load. Deleting the file permits a new baseline from the current save; it cannot reconstruct the original first-seen state.

The `TaumTest_322865388` copy passed the basic load, save, reload, and hutch inspection checks on 2026-10-26: seven vanilla slimes remained unmanaged and the external registry reloaded with zero records. Other foundation checks remain open.

## External slime identity probe

The game assembly exposes an `NPC.id` field in the `GreenSlime` inheritance chain, but its uniqueness and persistence are not established. The probe command is read-only and does not treat that field as a stable ID.

1. In a disposable save, enter a Slime Hutch and run `slime_ranching_probe_identity`.
2. Save the game, quit fully, reload the same save, enter the same hutch, and run it again.
3. Compare `NPC.id` values across reloads and among slimes in each run. A candidate is usable only if it stays stable for the same entity and is unique among simultaneous slimes. If either property fails, external matching remains blocked; do not register records by color, name, or position alone.

## Ranch Slime farm-animal prototype

This is a new custom farm-animal type in a separate Slime Daycare animal-house building; it does not modify existing monsters. The Daycare currently reuses the Barn's construction costs, exterior, interior map, and build time. Ranch Slimes use a temporary chicken sprite sheet.

1. Deploy the mod to a disposable save, open Robin's construction menu, and build the Slime Daycare.
2. After construction finishes, run `animal Taum.SlimeRanching_RanchSlime` outside all buildings.
3. Verify the new animal is assigned to the Daycare and can be petted; existing hutch and mine slimes should be unchanged.
4. Sleep to save. Check the log for `Added 1 Ranch Slime genome record(s) to the external registry`, then inspect `data/saves/<save name>/slime-registry-v1.json`: the record should have `FarmAnimalId` matching the animal and a `Genome.Id` in that external file.
5. Reload and save again. Confirm the same `FarmAnimalId` retains the same `Genome.Id` and no duplicate record is added.
6. Run `slime_ranching_inspect` in a Slime Hutch and confirm its vanilla slime count has not changed.

The custom Common Slime Egg does not hatch into this animal yet. Incubator integration and custom Daycare art/interior remain future steps.

## One-time starter reset (disposable save only)

The `slime_ranching_initialize` command intentionally changes the **game save**: it removes all current Slime Hutch slimes and gives the player one mod Common Slime Egg `(O)Taum.SlimeRanching_CommonEgg`. Mod-owned reset status is stored only in the mod folder. It never runs automatically, and it does not touch wild or mine slimes. The mod egg is a distinct item and is not yet incubatable.

1. Load a disposable copy of a save, enter a Slime Hutch, and make room for one egg in your inventory.
2. Run `slime_ranching_initialize <exact save folder name>` in the SMAPI console. For the current test copy, use `slime_ranching_initialize TaumTest_322865388`.
3. Verify all Slime Hutches are empty and exactly one Common Slime Egg was added. `slime_ranching_inspect` should say `Starter reset: pending game save`.
4. Sleep to save. Check the log for `Starter reset completed and recorded in the mod folder`, then inspect `data/saves/<save name>/slime-registry-v1.json` for `"StarterResetComplete": true`.
5. Reload the same save. The hutches should remain empty, the egg should remain in inventory, and repeating the command must grant nothing.

If the inventory has no room, the command should leave slimes untouched and grant no egg. Leaving without saving should restore the old hutch slimes on reload, and the command can be run again. If the game save completes but the external marker fails to write, do not repeat the command until the mod data is repaired.

## Slime Egg Converter

The new converter is a distinct big craftable `(BC)Taum.SlimeRanching_EggConverter`. It accepts one green `(O)680`, blue `(O)413`, red `(O)437`, purple `(O)439`, or tiger `(O)857` vanilla Slime Egg and produces one mod Common Slime Egg after ten in-game minutes. It uses the vanilla Slime Egg-Press sprite as a placeholder. Existing vanilla eggs in inventory, chests, treasure, drops, and the old press remain unchanged until deliberately inserted. The output is a custom item ID stored in the game save; removing the mod while it remains in the save leaves an Error Item.

1. Load the disposable `TaumTest_322865388` save and run `slime_ranching_give_converter TaumTest_322865388` in the SMAPI console. Place the new machine in the hutch.
2. Leave a vanilla egg in inventory and another in a chest. Sleep and reload: both must retain their original colors and item IDs.
3. The hutch's existing Slime Egg-Press has a Red Slime Egg ready. Collect it and verify it remains red. Insert it into the new converter. After ten in-game minutes, collect one mod Common Slime Egg.
4. Try inserting a non-egg item and the produced mod Common Slime Egg; neither should be consumed. Check that the old Slime Egg-Press still accepts Slime and that slain slimes still use vanilla egg drops.
5. Sleep and reload with the converter placed and a mod egg in inventory or chest. The machine and mod egg should still be recognized while the mod is installed. No genome or live slime management is implemented yet.

## Field Guide book

1. Load a disposable single-player save and run `slime_ranching_give_guidebook <exact save folder name>`.
2. Confirm the Field Guide appears in inventory. Select it and press the action button; the guide page should open and explain the current feature limits.
3. Close the page. The book should remain in inventory and should not be consumed.
4. Save and reload with the book present. Confirm the item remains recognized while the mod is installed.

## External food-like persistence

On a disposable mod-data copy, put one record with `Genome.Id` set to `00000001-0000-0000-0000-000000000000` and omit `Genome.LikedFoodItemId`. Load and save: the external `slime-registry-v1.json` should contain `"LikedFoodItemId": "(O)766"` inside `Genome`. Reload and save again: it must keep the same value. This only tests external persistence; it does not link the record to a live slime.

For migration, put `LikedFoodItemId` on the record outside `Genome` in a test copy. After load/save, it should appear only inside `Genome`, and `slime-registry-v1.json.before-food-like-move.bak` should preserve the original file.

## Unit tests
- Recipe table is symmetric where intended and never creates undefined hybrids.
- Crystal override always yields pure base color and preserves unrelated genetic rolls.
- Size probability distributions approximate configured weights under seeded simulations.
- Rarity, shiny and mutation rolls are independent where specified.
- Pool pity caps and resets correctly; no resource spent twice.
- Refinery conversion cannot yield free item loops.

## Integration tests
- Existing save with slimes; new save; save/reload mid-breeding; reload with egg in chest.
- Parent removed, breeder broken, hutch full, egg output occupied, player cancels.
- Hatching an egg after transferring it to another location; corrupt external identity/state fallback.
- Furniture interactions with many slimes and giant sprites; offscreen hutch.
- Companion item pickup, full inventory, travel, death/pass-out, festival and sleep.
- Black/White day transition with events, quests and multiplayer.

## Release checks
No duplicate entities/items, no save corruption, stable FPS in full hutch, clear configuration, compatible removal path, reproducible regression tests.
