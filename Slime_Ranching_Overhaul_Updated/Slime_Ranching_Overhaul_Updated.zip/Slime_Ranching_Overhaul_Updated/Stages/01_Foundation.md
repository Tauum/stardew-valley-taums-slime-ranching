# Stage 1 — Foundation and safety

Goal: prove the mod can coexist with vanilla before any breeding changes.

- Scope all managed behavior to explicitly tagged slime entities in Slime Hutch interiors. Never globally alter mine, Skull Cavern, Secret Woods, or other wild slimes.
- Maintain per-save versioned registry of genomes, bound companions, breeder reservations, and machine state. `config.json` is preferences only.
- Store the registry and snapshots under the installed mod folder. Do not write mod data to the Stardew save or to game entity/item `modData`.
- On first install, snapshot all preexisting hutch slimes into the mod folder. Leave legacy slimes untouched while external identity matching is unresolved.
- Plan vanilla-only save loads: uninstall executes no code; test vanilla tolerance of custom objects, keep backups, and offer reconciliation when reinstalled.
- Use a non-destructive test save and inspect SMAPI logs.

**Done when:** vanilla isolation verified in multiple locations; first-seen snapshot idempotent; mod-folder backup and reinstallation scenario tested.


