# Stage 2 — Fully custom breeder (first gameplay feature)

Build a placeable Slime Breeder with custom selection UI. Exactly two mature, eligible managed hutch slimes enter a transparent enclosure and are visually represented using their actual colors and genetic sizes, bouncing together throughout the cycle. Reserve parents so they cannot simultaneously roam/breed/be bound as companions. Approximate cycle target: two in-game days; exact balance adjustable. Implement parent cooldown and interruption/reload recovery.

At completion, compute the offspring genome **once** and keep it in the external mod registry. Reuse vanilla egg sprites and normal inventory presentation if a stable external identity scheme can distinguish eggs through inventory/chests/machines without writing to the game save. Eggs with different genome IDs must not stack or lose identity. This identity mechanism is an unresolved prerequisite; do not silently replace it with per-item save metadata. Integrate incubator hatching so a managed egg creates the stored juvenile exactly, with no reroll; unmanaged vanilla eggs retain vanilla behavior.

Disable passive vanilla reproduction **only** for managed hutch slimes. Do not patch all GreenSlimes globally. Track source parents, generation, species, genetic size, shiny, rarity, mutation and ability identifiers in versioned data.

**Done when:** select → animated parents → egg → incubate → correct juvenile → save/reload, with all non-hutch slimes unaffected.
