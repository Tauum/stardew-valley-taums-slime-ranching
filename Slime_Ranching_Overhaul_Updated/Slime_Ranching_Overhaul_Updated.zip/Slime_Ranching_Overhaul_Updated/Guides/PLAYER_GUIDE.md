# Slime Ranching Overhaul — Player Guide

This guide covers the features currently present in the mod. The mod is still an early prototype: breeding, hatching, and managed slime behavior are not available yet.

## Before you start

- Test on a copied save. The converter itself leaves unused vanilla eggs alone, but its output is a custom mod item saved in the game save.
- Back up `<installed mod folder>/data` before replacing or removing the mod. It contains the external slime registry and first-seen snapshots.
- The current converter is supplied by a testing command; there is no crafting recipe or shop source yet.

## Slime Egg Converter

The Slime Egg Converter turns one vanilla Slime Egg into one **Common Slime Egg** after ten in-game minutes.

### Get and place a converter

Open the SMAPI console while the intended single-player save is loaded and run:

```text
slime_ranching_give_converter <exact save folder name>
```

For the test copy used during development:

```text
slime_ranching_give_converter TaumTest_322865388
```

Place the converter somewhere you can access. You don't need to be in the Slime Hutch.

### Convert an egg

Put one green, blue, red, purple, or tiger Slime Egg into the converter. Collect the Common Slime Egg when processing finishes. Eggs elsewhere—in inventory, chests, treasure, drops, or the original Slime Egg-Press—remain vanilla eggs unless you put them into this converter.

The Common Slime Egg is not hatchable yet. The vanilla incubator won't produce a modded slime from it at this stage.

## Hutch inspection

Enter a Slime Hutch and run:

```text
slime_ranching_inspect
```

This reports the number of vanilla slimes in the current hutch, the number of external mod records, and whether the optional starter reset has run. Slimes are not yet managed by the mod.

For identity research, `slime_ranching_probe_identity` prints read-only candidate data for each slime in the current hutch. It does not assign IDs or change the save. Its `NPC.id` value is only a candidate until uniqueness and save/reload stability are confirmed.

## Field Guide book

The in-game **Slime Ranching Field Guide** is a short introduction to the current features. For testing, request it from the SMAPI console with the exact save folder name:

```text
slime_ranching_give_guidebook <exact save folder name>
```

Select the book and press the action button to open it. It is a custom item reference in the game save, so keep the mod installed while the book remains in that save. This markdown guide has the fuller usage details.

## Optional one-time starter reset

This command is destructive to the current save: it removes every slime from every Slime Hutch and grants one mod Common Slime Egg. It does not remove wild or mine slimes. Run it only on a disposable save, while standing in a Slime Hutch, after confirming the exact save folder name:

```text
slime_ranching_initialize <exact save folder name>
```

The change takes effect immediately in the game. Sleep to save it and let the mod record the one-time completion marker in its external data. Don't run it again if the marker write reports an error; repair the mod data first.

## Features still under development

- **Hatching:** Common Slime Eggs do not hatch yet.
- **Breeding:** There is no breeder, parent selection, cycle, or offspring genetics yet.
- **Genetics and slime identity:** The registry model can hold genome data, but records aren't matched to live slimes. Existing slimes are only captured in the first-seen snapshot; they aren't changed or adopted.
- **Food likes, furniture, production, and companions:** These systems are planned but aren't active gameplay features yet.

## Ranch Slime animal prototype

The mod now defines a **Slime Daycare**, a separate animal-house building, and a **Ranch Slime** farm-animal type. The Daycare currently reuses the Barn's exterior, interior map, build time, and materials as placeholders; Ranch Slimes still use a temporary chicken sprite sheet. Build a Slime Daycare through Robin, then use the game's animal command outside all buildings:

```text
animal Taum.SlimeRanching_RanchSlime
```

This spawns a farm-animal prototype; it does not convert or remove any existing vanilla slimes. Petting, movement, Daycare assignment, and save/reload still need in-game verification. When the game saves, the mod records its genome externally and links it to the animal's native farm-animal ID. Standard animal properties like its name, home, age, and friendship remain part of Stardew's normal animal save data.

## Data and save behavior

The mod keeps its registry and first-seen snapshot under:

```text
<installed mod folder>/data/saves/<save folder name>/
```

The converter, Field Guide, and Common Slime Egg are custom item references in the Stardew save. If the mod is removed while one remains in a save, Stardew will show it as an Error Item. The Slime Daycare building and Ranch Slime animals are native game entities saved by Stardew. Existing `GreenSlime` monsters are not matched or changed. Ranch Slime genome records are stored externally and keyed by the native FarmAnimal ID; normal farm-animal properties remain in the save.

## Development book status

The in-game book is a short overview; this file is the detailed player guide. Expand both with a dedicated section as each feature is implemented and tested, keeping unavailable features clearly labeled.
